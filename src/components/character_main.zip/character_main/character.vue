<template>
  <svg
    width="420"
    height="380"
    viewBox="0 0 420 380"
    style="width: 100%; height: 100%"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g>
      <!-- Back -->
      <g>
        <outfit
          :isBack="false"
          :isFront="false"
          :item="studentStore.characterData.head"
        ></outfit>
        <outfit
          :isBack="false"
          :isFront="false"
          :item="studentStore.characterData.footer"
        ></outfit>
        <outfit
          :isBack="false"
          :isFront="false"
          :item="studentStore.characterData.body"
        ></outfit>
      </g>

      <!-- Skeleton -->
      <skeleton :bodyColor="studentStore.characterData.color"></skeleton>
      <!-- Fornt -->

      <g>
        <!-- Header -->
        <outfit
          :isBack="false"
          :isFront="false"
          :item="studentStore.characterData.head"
        ></outfit>
        <outfit
          :isBack="false"
          :isFront="false"
          :item="studentStore.characterData.footer"
        ></outfit>
        <outfit
          :isBack="false"
          :isFront="false"
          :item="studentStore.characterData.body"
        ></outfit>
      </g>
    </g>
    <style-equipment></style-equipment>
  </svg>
</template>

<script>
import styleEquipment from "./style_equipment.vue";
import skeleton from "./skeleton.vue";
import outfit from "./outfit.vue";
import { useStudentStore } from "src/store/student";
export default {
  components: {
    styleEquipment,
    skeleton,
    outfit,
  },

  setup() {
    const studentStore = useStudentStore();

    return {
      studentStore,
    };
  },
};
</script>

<style lang="scss" scoped>
@import url("../../css/animation-eyes.css");
</style>
