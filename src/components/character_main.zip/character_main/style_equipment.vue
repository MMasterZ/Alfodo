<template>
  <defs>
    <!--  -->
    <radialGradient
      id="cheek_paint_radial_0_1"
      cx="0"
      cy="0"
      r="1"
      gradientUnits="userSpaceOnUse"
      gradientTransform="translate(179.945 165.051) rotate(90) scale(7.1953 10.765)"
    >
      <stop stop-color="#FF7171" stop-opacity="0.7" />
      <stop offset="1" stop-color="#FF7171" stop-opacity="0" />
    </radialGradient>
    <radialGradient
      id="cheek_paint_radial_0_2"
      cx="0"
      cy="0"
      r="1"
      gradientUnits="userSpaceOnUse"
      gradientTransform="translate(241.431 165.051) rotate(90) scale(7.1953 10.765)"
    >
      <stop stop-color="#FF7171" stop-opacity="0.7" />
      <stop offset="1" stop-color="#FF7171" stop-opacity="0" />
    </radialGradient>
    <radialGradient
      id="note_paint_radial_0_1"
      cx="0"
      cy="0"
      r="1"
      gradientUnits="userSpaceOnUse"
      gradientTransform="translate(210.357 159.007) rotate(90) scale(4.60323 6.88694)"
    >
      <stop stop-color="#FC9C67" stop-opacity="0.71" />
      <stop offset="1" stop-color="#FC9C67" stop-opacity="0" />
    </radialGradient>

    <!--  -->
  </defs>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
