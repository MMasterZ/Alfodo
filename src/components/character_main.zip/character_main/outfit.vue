<template>
  <g>
    <image
      :href="`/images/store_character/${item}${
        isBack ? '-back' : isFront ? '-front' : ''
      }.png`"
      v-if="item"
    ></image>
  </g>
</template>

<script>
export default {
  props: {
    isBack: {
      type: Boolean,
      default: false,
    },
    isFront: {
      type: Boolean,
      default: false,
    },
    item: {
      type: String,
      default: "",
    },
  },
};
</script>

<style lang="scss" scoped></style>
