import axios from 'axios'
import { defineStore } from 'pinia'
import { useInventoryStore } from './inventory'
import { useStudentStore } from './student'
import { useSystemStore } from './system'

const styleAlertColor = 'color:#e65212;background-color:#000;font-weight: bold;'
console.log(`%c *****  ItemShop Store Log Color  ***** `, `${styleAlertColor}`)

export const useItemShopStore = defineStore('itemShopStore', {
  state: () => ({
    itemshop: {
      data: [],
      isLoaded: false
    }
  }),
  getters: {
    itemHead: state => {
      let temp = state.itemshop.data.filter(x => x.type == 'head')
      temp = state.hasItem(temp, 'head')
      temp = state.separateItem(temp)
      return temp
    },
    itemBody: state => {
      let temp = state.itemshop.data.filter(x => x.type == 'body')
      temp = state.hasItem(temp, 'body')
      temp = state.separateItem(temp)
      return temp
    },
    itemFooter: state => {
      let temp = state.itemshop.data.filter(x => x.type == 'footer')
      temp = state.hasItem(temp, 'footer')
      temp = state.separateItem(temp)
      return temp
    },
    itemPet: state => {
      let temp = state.itemshop.data.filter(x => x.type == 'pet')
      temp = state.hasItem(temp, 'pet')
      temp = state.separateItem(temp)
      return temp
    },
    itemOther: state => {
      let temp = state.itemshop.data.filter(x => x.type == 'other')
      temp = state.hasItem(temp, 'other')
      temp = state.separateItem(temp)
      return temp
    }
  },
  actions: {
    async getItemShop () {
      if (this.itemshop.isLoaded) return

      try {
        let APIURL = `${process.env.NEWAPI}/itemShop-getItemShop`

        let response = await axios.get(APIURL)

        this.$patch({
          itemshop: {
            data: response.data,
            isLoaded: true
          }
        })

        this.log(`Success Get Item Shop`)
      } catch (e) {
        this.log(`Error Get Item Shop`)

        return e
      }
    },
    async buyItemShop (items, color) {
      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/itemShop-buyItem`

        const postData = {
          studentId: studentStore.studentId,
          itemIds: items,
          color: color
        }

        await axios.post(APIURL, postData)

        this.log(`Success Buy Item Shop`)
      } catch (e) {
        this.log(`Error Buy Item Shop`)
        return e
      }
    },

    // *********************** Other ***********************
    separateItem (array) {
      let temp = []

      let setShowNumber = 9
      let totalPage = Math.ceil(array.length / setShowNumber)
      let start = 0
      let end = 9

      for (let i = 0; i < totalPage; i++) {
        let newSet = array.slice(start, end)
        temp.push(newSet)
        start += setShowNumber
        end += setShowNumber
      }

      return temp
    },
    hasItem (array, type) {
      const inventoryStore = useInventoryStore()

      let temp = array

      temp.forEach(res => {
        let findHasItem = inventoryStore.inventory.data[type].filter(
          x => x.itemName == res.itemName
        )
        if (findHasItem.length) res.isHas = true
        else res.isHas = false
      })

      return temp
    },
    log (text) {
      const systemStore = useSystemStore()

      if (systemStore.isShowLog)
        console.log(`%c ${text} `, `${styleAlertColor}`)
    }
  }
})
