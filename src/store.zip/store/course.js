import axios from 'axios'
import { defineStore } from 'pinia'
import { useStudentStore } from './student'
import { useSystemStore } from './system'

// Inititalize Data
const styleAlertColor = 'color:#00bf1d;background-color:#000;font-weight: bold;'
console.log(`%c *****  Course Store Log Color  ***** `, `${styleAlertColor}`)

export const useCourseStore = defineStore('courseStore', {
  state: () => {
    return {
      course: {
        data: {},
        isUpdate: false
      },
      courseList: {
        data: [],
        isUpdate: false
      }
    }
  },

  getters: {
    courseLevel: state => state.course.data.level,
    courseLevelOptions: state => {
      let temp = state.courseList.data

      temp = temp.map(x => x.level)

      return temp
    },
    courseBuyOptions: state => {
      let temp = []

      return temp
    },
    class: state => state.course.data.class,
    room: state => state.course.data.room,
    term: state => state.course.data.term,
    year: state => state.course.data.year,
    star: state => state.course.data.star || 0
  },
  actions: {
    async getCourse () {
      // if (this.course.isLoaded && !this.course.isUpdate) return

      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/course-getCourseByCourseId?courseId=${studentStore.courseId}`

        const response = await axios.get(APIURL)

        this.course.data = response.data
        this.course.isUpdate = false

        this.log(`Success Get Course`)
      } catch (e) {
        this.log(`Error Get Course`)

        return e
      }
    },
    async getAllCourse () {
      // if (this.courseList.isLoaded && !this.courseList.isUpdate) return

      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/course-getAllCourseByStudentId?studentId=${studentStore.studentId}`

        const response = await axios.get(APIURL)

        this.courseList.data = response.data
        this.courseList.isUpdate = false

        this.log(`Success Get All Course`)
      } catch (e) {
        this.log(`Error Get All Course`)

        return e
      }
    },

    log (text) {
      const systemStore = useSystemStore()

      if (systemStore.isShowLog)
        console.log(`%c ${text} `, `${styleAlertColor}`)
    }
  }
})
