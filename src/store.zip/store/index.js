import { store } from 'quasar/wrappers'
import { createPinia } from 'pinia'
import { createPersistedStatePlugin } from 'pinia-plugin-persistedstate-2'
import cloneDeep from 'clone-deep'

/*
 * If not building with SSR mode, you can
 * directly export the Store instantiation;
 *
 * The function below can be async too; either use
 * async/await or return a Promise which resolves
 * with the Store instance.
 */

export default store(function (/* { ssrContext } */) {
  const store = createPinia()

  const installPersistedStatePlugin = createPersistedStatePlugin({
    persist: true,
    storage: sessionStorage
  })

  store.use(context => {
    installPersistedStatePlugin(context)
  })

  return store
})
