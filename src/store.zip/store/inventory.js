import axios from 'axios'
import { defineStore } from 'pinia'
import { useStudentStore } from './student'
import { useSystemStore } from './system'

const styleAlertColor = 'color:#FF23FF;background-color:#000;font-weight: bold;'
console.log(`%c *****  Inventory Store Log Color  ***** `, `${styleAlertColor}`)

export const useInventoryStore = defineStore('inventoryStore', {
  state: () => {
    return {
      inventory: {
        data: [],
        isLoaded: false,
        isUpdate: false
      }
    }
  },

  getters: {
    head: state => state.inventory.data.head,
    body: state => state.inventory.data.body,
    footer: state => state.inventory.data.footer,
    pet: state => state.inventory.data.pet,
    other: state => state.inventory.data.other,
    isLoading: state => {
      if (state.inventory.isUpdate) return true
      else return false
    }
  },
  actions: {
    // Add
    async addInventory () {
      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/inventory-addInventoryOnCreateCharacter`

        const POSTDATA = {
          studentId: studentStore.studentId,
          items: [
            {
              ...studentStore.characterData.head,
              type: 'head'
            },
            {
              ...studentStore.characterData.body,
              type: 'body'
            },
            {
              ...studentStore.characterData.footer,
              type: 'footer'
            }
          ]
        }

        await axios.post(APIURL, POSTDATA)

        this.inventory.isUpdate = true
        this.log(`Success Add Inventory `)
      } catch (e) {
        this.log(`Error Add Inventory `)

        return e
      }
    },
    async getInventory () {
      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/inventory-getInventoryByStudentId?studentId=${studentStore.studentId}`

        const response = await axios.get(APIURL)

        this.$patch({
          inventory: {
            data: response.data,
            isLoaded: true,
            isUpdate: false
          }
        })

        this.log(`Success Get Inventory `)
      } catch (e) {
        this.log(`Error Get Inventory `)

        return e
      }
    },
    log (text) {
      const systemStore = useSystemStore()

      if (systemStore.isShowLog)
        console.log(`%c ${text} `, `${styleAlertColor}`)
    }
  }
})
