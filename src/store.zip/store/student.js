import axios from 'axios'
import { defineStore } from 'pinia'
import { useSchoolStore } from './school'
import { useSystemStore } from './system'

// Inititalize Data

const styleAlertColor = 'color:#d60000;background-color:#000;font-weight: bold;'
console.log(`%c *****  Student Store Log Color  ***** `, `${styleAlertColor}`)

export const useStudentStore = defineStore('studentStore', {
  state: () => ({
    student: {
      uid: '',
      data: {},
      isUpdateCoin: false,
      isUpdateCharacter: false
    }
  }),
  getters: {
    // Student
    studentData: state => state.student.data,
    studentFullName: state =>
      `${state.student.data.name} ${state.student.data.surname}`,
    studentLevel: state => state.student.data.level,
    studentType: state => state.student.data.type,
    studentId: state => state.student.uid,

    // game data
    coin: state => state.student.data.coin,
    progressLevel: state => state.student.data.levelProgressBar * 100,

    // Character
    characterName: state =>
      state.student.data.character ? state.student.data.character.name : '',
    characterData: state => state.student.data.character,
    isHasCharacter: state => state.student.data.isCreateCharacter,

    // Course
    courseId: state => state.student.data.currentCourseId,

    // School
    schoolId: state => state.student.data.schoolId,

    isPretest: state => state.student.data.pretest || false,
    isPosttest: state => state.student.data.posttest || false,
    isLoading: state => {
      if (state.student.isUpdateCharacter) return true
      else return false
    }
  },
  actions: {
    // Get
    async getLevel () {
      try {
        const APIURL = `${process.env.NEWAPI}/student-getLevel?studentId=${this.studentId}`

        const response = await axios.get(APIURL)

        this.$patch({
          student: {
            data: {
              exp: response.data.exp,
              level: response.data.level,
              levelProgressBar: response.data.levelProgressBar
            }
          }
        })

        this.log('Success Get Level')
      } catch (e) {
        this.log('Error Get Level')

        return e
      }
    },
    async getCoin () {
      try {
        const APIURL = `${process.env.NEWAPI}/student-getCoin?studentId=${this.studentId}`

        const response = await axios.get(APIURL)

        this.$patch({
          student: {
            data: {
              coin: Number(response.data)
            }
          }
        })

        this.log('Success Get Coin')
      } catch (e) {
        this.log('Error Get Coin')

        return e
      }
    },
    async getRanking () {
      try {
        const APIURL = `${process.env.NEWAPI}/ranking-getSchoolRanking?schoolId=${this.schoolId}&studentId=${this.studentId}`

        let response = await axios.get(APIURL)

        this.log('Success Get Ranking')

        return response.data
      } catch (e) {
        this.log('Error Get Ranking')

        return e
      }
    },
    async getCharacterInfo () {
      try {
        const APIURL = `${process.env.NEWAPI}/character-getCharacterInfo?studentId=${this.studentId}`

        let response = await axios.get(APIURL)

        console.log(response.data)

        this.student.data.character = {
          ...response.data,
          other: response.data.other || {
            isFront: false,
            isBack: false,
            itemName: ''
          }
        }

        this.log('Success Get Character')
      } catch (e) {
        this.log('Error Get Character')

        return e
      }
    },
    async getPrepostLog () {
      try {
        const schoolStore = useSchoolStore()

        let type = 'pretest'
        if (schoolStore.isPosttest) type = 'posttest'
        if (schoolStore.isPretest) type = 'pretest'
        if (!schoolStore.isPosttest && !schoolStore.isPretest) return

        const APIURL = `${process.env.NEWAPI}/prePostLog-checkPrePostLog?courseId=${this.courseId}&type=${type}`

        const response = await axios.get(APIURL)

        let isHasTest = false
        if (response.data == 'passed') isHasTest = true
        else isHasTest = false

        this.$patch({
          student: {
            data: {
              [type]: isHasTest
            }
          }
        })

        this.log('Success Get Per-test && Post-test Log')
      } catch (e) {
        this.log('Error Get Per-test && Post-test Log')

        return e
      }
    },

    // Update, Set, Save
    async setCharacter () {
      try {
        const APIURL = `${process.env.NEWAPI}/character-setCharacter`

        this.$patch(state => {
          state.student.isUpdateCharacter = true
        })

        const POSTDATA = {
          studentId: this.studentId,
          color: this.characterData.color,
          head: this.characterData.head,
          body: this.characterData.body,
          footer: this.characterData.footer,
          pet: this.characterData.pet,
          other: this.characterData.other,
          name: this.characterData.name
        }

        await axios.post(APIURL, POSTDATA)

        this.$patch(state => {
          state.student.isUpdateCharacter = false
        })

        this.log('Success Set Character')
      } catch (e) {
        this.log('Error Set Character')

        return e
      }
    },
    async updateCoin (coin) {
      try {
        const APIURL = `${process.env.NEWAPI}/student-updateCoin`

        const postData = {
          studentId: this.studentId,
          coin: Number(coin)
        }

        await axios.post(APIURL, postData)

        this.$patch({
          student: {
            isUpdateCoin: true
          }
        })

        this.log('Success Update Coin')
      } catch (e) {
        this.log('Error Update Coin')

        return e
      }
    },
    async updateCreateCharacter () {
      try {
        const APIURL = `${process.env.NEWAPI}/student-updateCreateCharacterStatus`

        const POSTDATA = {
          studentId: this.studentId
        }

        await axios.post(APIURL, POSTDATA)

        this.log('Success Update Create Character')
      } catch (e) {
        this.log('Error Update Create Character')

        return e
      }
    },

    // Setter
    async saveCharacterName (name) {
      try {
        this.$patch({
          student: {
            data: {
              character: {
                name: name
              }
            }
          }
        })

        const APIURL = `${process.env.NEWAPI}/character-setCharacterName`

        const POSTDATA = {
          studentId: this.studentId,
          name: name
        }

        await axios.post(APIURL, POSTDATA)

        this.log('Success Save Character Name')
      } catch (e) {
        this.log('Error Save Character Name')

        return e
      }
    },

    // Setter
    setPrePost (type, status) {
      this.$patch({
        student: {
          data: {
            [type]: status
          }
        }
      })
    },
    setUpdateCoin () {
      this.$patch({
        student: {
          isUpdateCoin: true
        }
      })
    },
    setName (name) {
      this.$patch({
        student: {
          data: {
            character: {
              name: name
            }
          }
        }
      })
    },
    setColor (color) {
      this.$patch({
        student: {
          data: {
            character: {
              color: color
            }
          }
        }
      })
    },
    setCharacterData (items) {
      items.forEach(res => {
        let newData = {
          isFront: res.isFront || false,
          isBack: res.isBack || false,
          itemName: res.itemName
        }

        this.$patch({
          student: {
            data: {
              character: {
                [res.type]: newData
              }
            }
          }
        })
      })
    },
    errorStudentIsUndefind () {
      try {
        if (this.studentId == '') throw ''
      } catch (e) {
        this.showLog(`Error : Student is Undefind`)
        window.location.href = '/'
      }
    },

    // Console Log
    log (text) {
      const systemStore = useSystemStore()

      if (systemStore.isShowLog)
        console.log(`%c ${text} `, `${styleAlertColor}`)
    }
  }
})
