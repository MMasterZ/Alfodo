import { defineStore } from 'pinia'
import { useSystemStore } from './system'

const styleAlertColor = 'color:#23c6cf;background-color:#000;font-weight: bold;'
console.log(
  `%c *****  Synchronize Store Log Color  ***** `,
  `${styleAlertColor}`
)

export const useSynchronizeStore = defineStore('synchronizeStore', {
  state: () => ({
    synchronize: {
      data: {},
      isUpdate: false
    },
    isSynchronize: false
  }),
  getters: {
    isSync: state => state.isSynchronize,
    syncData: state => {
      let setSyncData = {
        isSync: state.isSynchronize,
        ...state.synchronize.data
      }

      if (setSyncData) return setSyncData
      else {
      }
    },
    isStartReview: state =>
      state.synchronize.data.lesson.isStartReview || false,
    isFinishPractice: state =>
      state.synchronize.data.lesson.isFinishPractice || false,
    isRestart: state => state.synchronize.data.lesson.isRestart || false
  },
  actions: {
    setSynchronizeData (data) {
      this.synchronize.data = data
    },
    log (text) {
      const systemStore = useSystemStore()

      if (systemStore.isShowLog)
        console.log(`%c ${text} `, `${styleAlertColor}`)
    }
  }
})
