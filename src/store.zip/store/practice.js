import axios from 'axios'
import { defineStore } from 'pinia'

const styleAlertColor = 'color:#534aff;background-color:#000;font-weight: bold;'
console.log(
  `%c *****  Practice Store And Show Log  ***** `,
  `${styleAlertColor}`
)

import vocabularyPracticePosition from '../../public/position-vocabulary-practice'
import grammarPracticePosition from '../../public/position-grammar-practice'
import readingPracticePosition from '../../public/position-reading-practice'
import writingPracticePosition from '../../public/position-writing-practice'
import phonicsPracticePosition from '../../public/position-phonics-practice'
import listeningPracticePosition from '../../public/position-listening-practice'
import { useStudentStore } from './student'
import { useCourseStore } from './course'
import { useSynchronizeStore } from './synchronize'
import { useSystemStore } from './system'

/**
 * @name practiceStore
 */
export const usePracticeStore = defineStore('practiceStore', {
  state: () => ({
    practiceListName: {
      data: {},
      isLoaded: false
    },
    practiceList: {
      data: [],
      isLoaded: false
    },
    practiceLog: {
      data: [],
      isLoaded: false,
      isLoading: false,
      isUpdate: false
    },

    // Practice Data
    practiceData: {
      couter: 0,
      type: '',
      id: '',
      skill: 'Vocabulary',
      level: '',
      unit: '1'
    }
  }),

  getters: {
    data: state => state.practiceData.data,
    practice: state => state.practiceData.practice,
    listName: state => state.practiceListName.data,
    list: state => state.practiceList.data,
    log: state => {
      let temp = state.practiceLog.data

      return temp
    },
    skill: state => state.practiceData.skill,
    unit: state => state.practiceData.unit,
    level: state => state.practiceData.level,
    practiceType: state => state.practiceData.type,
    practiceListId: state => state.practiceData.id,
    listBySkill: state => {
      let temp = []
      let tempSkillPosition = []
      let skillName = state.practiceData.skill

      if (state.practiceData.skill == 'Vocabulary') {
        tempSkillPosition = vocabularyPracticePosition.list
      } else if (state.practiceData.skill == 'Grammar') {
        tempSkillPosition = grammarPracticePosition.list
      } else if (state.practiceData.skill == 'Reading') {
        tempSkillPosition = readingPracticePosition.list
      } else if (state.practiceData.skill == 'Writing') {
        tempSkillPosition = writingPracticePosition.list
      } else if (state.practiceData.skill == 'Phonics') {
        tempSkillPosition = phonicsPracticePosition.list
      } else {
        tempSkillPosition = listeningPracticePosition.list
        skillName = 'Listening & Speaking'
      }

      let findPractice = state.practiceList.data.filter(
        x => x.unit == state.practiceData.unit && x.skill == skillName
      )

      let findPracticePosition = tempSkillPosition.filter(
        x => x.length == findPractice.length
      )

      findPractice.forEach((res, index) => {
        let isLesson = false
        let isLearn = false
        let isDisable = false
        let star = 0
        let isRoleplay = false
        let counter = 0

        let findLog = state.practiceLog.data.find(
          x => x.practiceListId == res.id
        )

        if (
          res.practiceType == 'flashcard' ||
          res.practiceType == 'grammarlesson' ||
          res.practiceType == 'phonicslesson' ||
          res.practiceType == 'languagetips' ||
          res.practiceType == 'conversationlesson'
        ) {
          isLesson = true
        } else if (res.practiceType == 'roleplay') {
          isRoleplay = true
        }

        // else {
        //   if (res.skill == 'Vocabulary') {
        //     // isDisable = true
        //   }
        // }

        if (findLog) {
          if (findLog.counter != 0) {
            isLearn = true
          }

          star = findLog.star

          counter = findLog.counter
        }

        if (index > 0) {
          if (temp[index - 1].isLearn) {
            if (res.skill == 'Vocabulary') {
              isDisable = false
            }
          } else {
            if (res.skill == 'Vocabulary') {
              isDisable = true
            }
          }
        }

        let newData = {
          ...findPracticePosition[0][index],
          ...res,
          star: star,
          index: index + 1,
          isLesson: isLesson,
          isLearn: isLearn,
          isRoleplay: isRoleplay,
          isDisable: isDisable,
          counter: counter
        }
        temp.push(newData)
      })

      return temp
    },
    direction: state => {
      if (state.practiceData.id) {
        let instruction = {
          eng: '',
          th: ''
        }

        let findInstruction = state.practiceList.data.find(
          x => x.id == state.practiceData.id
        )

        if (state.practiceData.type == 'flashcard') {
          instruction = {
            eng: "Let's start reviewing VOCABULARY!!",
            th: 'มาเริ่มทบทวนคำศัพท์กัน!'
          }
        } else {
          if (findInstruction)
            instruction = {
              eng: findInstruction.instructionEng,
              th: findInstruction.instructionTh
            }
        }

        return instruction
      }
      return null
    },
    isLoading: state => {
      if (
        !state.practiceList.isLoaded ||
        !state.practiceLog.isLoaded ||
        !state.practiceListName.isLoaded ||
        state.practiceLog.isLoading
      ) {
        return true
      } else return false
    }
  },

  actions: {
    /**
     * @constructor
     * @param {String} courseLevel - เลเวลของคอร์สเรียน
     * @returns x
     */
    // ====================  Function Get Practice ====================
    async getPracticeListName () {
      if (this.practiceListName.isLoaded) return

      try {
        const courseStore = useCourseStore()

        const APIURL = `${process.env.NEWAPI}/practiceListName-getPracticeListNameByLevel?level=${courseStore.courseLevel}`

        const response = await axios.get(APIURL)

        this.$patch({
          practiceListName: {
            data: response.data,
            isLoaded: true
          },
          practiceData: {
            level: courseStore.courseLevel
          }
        })
        this.showLog(`Success Get Practice List Name `)
      } catch (e) {
        this.showLog(e)
        this.showLog(`Error Get Practice List Name `)
        return e
      }
    },

    async getPracticeList () {
      if (this.practiceList.isLoaded) return

      try {
        const courseStore = useCourseStore()

        const APIURL = `${process.env.NEWAPI}/practiceList-getPracticeListByLevel?level=${courseStore.courseLevel}`

        const response = await axios.get(APIURL)

        this.$patch({
          practiceList: {
            data: response.data,
            isLoaded: true
          }
        })
        this.showLog(`Success Get Practice List `)
      } catch (e) {
        this.showLog(`Error Get Practice List `)
        return e
      }
    },

    async getPracticeLog () {
      if (this.practiceLog.isLoaded) return

      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/practiceLog-getPracticeLogByStudentIdAndCourseId?studentId=${studentStore.studentId}&courseId=${studentStore.courseId}`

        const response = await axios.get(APIURL)

        this.$patch({
          practiceLog: {
            data: response.data,
            isLoaded: true
          }
        })
        this.showLog(`Success Get Practice Log `)
      } catch (e) {
        this.showLog(`Error Get Practice Log `)
        return e
      }
    },

    async getFlashcardLearningPractice () {
      try {
        const studentStore = useStudentStore()
        const synchronizeStore = useSynchronizeStore()

        let currentIdFlashcard = this.list.filter(
          x => x.skill == 'Vocabulary' && x.unit == this.unit
        )[0]

        const APIURL = `${process.env.NEWAPI}/practice-getFlashcardLearningPractice?practiceListId=${currentIdFlashcard.id}&studentId=${studentStore.studentId}&unit=${this.unit}&isSync=${synchronizeStore.isSync}`

        const response = await axios.get(APIURL)

        let temp = []

        response.data.forEach(res => {
          let description = ''

          description = res.vocab

          let newData = {
            ...res,
            tagAudioUrl: new Audio(res.audioUrl),
            description: description,
            isFinish: false
          }

          temp.push(newData)
        })

        this.showLog(`Success Get Flashcard Learning Practice `)

        return temp
      } catch (e) {
        this.showLog(`Error Get Flashcard Learning Practice `)
        return e
      }
    },

    async getVocabMultipleByPracticeListId () {
      try {
        const APIURL = `${process.env.NEWAPI}/practice-getVocabMultipleByPracticeListId?practiceListId=${this.practiceListId}`

        const response = await axios.get(APIURL)

        let temp = response.data

        temp.forEach(res => {
          res.isCorrect = false
        })

        this.showLog(`Success Get Vocab Multiple By Practice `)
        return temp
      } catch (e) {
        this.showLog(`Error Get Vocab Multiple By Practice `)
        return e
      }
    },

    async getFlashcard () {
      try {
        const APIURL = `${process.env.NEWAPI}/practice-getFlashcard?practiceListId=${this.practiceData.id}`

        const response = await axios.get(APIURL)

        let temp = []

        response.data.forEach(res => {
          let newData = {
            ...res,
            tagAudioSentenceUrl: new Audio(res.soundSentenceUrl),
            tagAudioSpellUrl: new Audio(res.soundSpellUrl),
            tagAudioVocabUrl: new Audio(res.soundVocabUrl)
          }

          temp.push(newData)
        })

        this.showLog(`Success Get Flashcard`)
        return temp
      } catch (e) {
        this.showLog(`Error Get Flashcard`)

        return e
      }
    },
    // ====================  Function Get Practice ====================

    // ==================== Function Save Incorrect Practice and Remove Incorrect Practice ====================
    async saveIncorrectPractice (questionId, data) {
      try {
        const studentStore = useStudentStore()

        let currentIdFlashcard = this.list.filter(
          x => x.skill == 'Vocabulary' && x.unit == this.unit
        )[0]

        const APIURL = `${process.env.NEWAPI}/incorrectPracticeLog-saveIncorrectPractice`

        delete data.incorrect

        const POSTDATA = {
          questionId: questionId,
          practiceListId: currentIdFlashcard.id,
          studentId: studentStore.studentId,
          question: data
        }

        await axios.post(APIURL, POSTDATA)

        this.log(`Success Save Incorrect Practice Log`)
      } catch (e) {
        this.log(`Error Save Incorrect Practice Log`)
        return e
      }
    },
    async saveSynchronizeFlashcardPractice (isFinish, score, progress, temp) {
      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/course-saveSynchronizeFlashcardPractice`

        let newTempData = temp.map(x => {
          return { vocab: x.vocab, score: x.score || 0 }
        })

        const POSTDATA = {
          courseId: studentStore.courseId,
          isFinish: isFinish,
          progress: progress,
          scoreAvg: score,
          vocab: newTempData,
          name: studentStore.studentFullName,
          practiceListId: this.practiceListId
        }

        await axios.post(APIURL, POSTDATA)
      } catch (e) {
        return e
      }
    },

    async saveUpdateCourseSync (currentQuestion, tempAnswer, score) {
      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/course-updateCourseSync`

        let POSTDATA = {
          courseId: studentStore.courseId,
          currentQuestion: currentQuestion,
          currentPracticeListId: this.practiceListId,
          answer: tempAnswer,
          currentScore: score
        }

        await axios.post(APIURL, POSTDATA)

        this.showLog(`Success Save Update Course Sync`)
      } catch (e) {
        this.showLog(`Error Save Update Course Sync`)
        return e
      }
    },

    async removeIncorrectPractice (incorrectId) {
      try {
        const APIURL = `${process.env.NEWAPI}/incorrectPracticeLog-removeIncorrectPracticeLog?incorrectPracticeLogId=${incorrectId}`

        await axios.get(APIURL)

        this.showLog(`Success Remove Incorrect Practice Log`)
      } catch (e) {
        this.showLog(`Error Remove Incorrect Practice Log`)

        return e
      }
    },
    async savePracticeLog (practice, isSync) {
      try {
        const studentStore = useStudentStore()
        const synchronizeStore = useSynchronizeStore()

        if (
          practice.counter == 0 &&
          practice.score < 50 &&
          !synchronizeStore.isSync
        ) {
          return
        }

        let findPracticeLog = this.practiceLog.data.find(
          x => x.practiceListId == this.practiceListId
        )

        let tempLog = []

        if (findPracticeLog) {
          if (!synchronizeStore.isSync) {
            if (findPracticeLog.counter != 2) findPracticeLog.counter++
          }

          if (practice.score > findPracticeLog.score)
            findPracticeLog.score = practice.score || 0

          if (practice.star > findPracticeLog.star)
            findPracticeLog.star = practice.star || 0

          this.$patch({
            practiceData: {
              counter: findPracticeLog.counter
            }
          })
        } else {
          let setCounter = 0

          if (!synchronizeStore.isSync) setCounter = 1

          let tempLogData = {
            counter: setCounter,
            courseId: studentStore.courseId,
            practiceListId: this.practiceListId,
            score: practice.score,
            star: practice.star,
            studentId: studentStore.studentId
          }

          tempLog = this.practiceLog.data
          tempLog.push(tempLogData)

          this.$patch({
            practiceLog: {
              data: tempLog
            }
          })
        }

        const APIURL = `${process.env.NEWAPI}/practiceLog-savePracticeLog`

        const POSTDATA = {
          practiceListId: this.practiceListId,
          score: practice.score,
          star: practice.star,
          studentId: studentStore.studentId,
          coin: practice.coin,
          mode: practice.mode,
          isSync: synchronizeStore.isSync
        }

        await axios.post(APIURL, POSTDATA)

        this.showLog(`Success Save Practice Log`)
      } catch (e) {
        this.showLog(`Error Save Practice Log`)
        return e
      }
    },

    // ==================== Function Save Incorrect Practice and Remove Incorrect Practice ====================

    // Setter
    setPracticeData (data) {
      let newSkill =
        data.skill === 'Listening & Speaking' ? 'Listening' : data.skill

      this.$patch({
        practiceData: {
          counter: data.counter,
          id: data.id || data.practiceListId,
          type: data.practiceType,
          skill: newSkill
        }
      })
    },

    // Log
    showLog (text) {
      const systemStore = useSystemStore()

      if (systemStore.isShowLog)
        console.log(`%c ${text} `, `${styleAlertColor}`)
    }
  }
})
