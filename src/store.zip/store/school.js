import axios from 'axios'
import { defineStore } from 'pinia'
import { useStudentStore } from './student'
import { useSystemStore } from './system'

// Inititalize Data
const styleAlertColor = 'color:#b6bf00;background-color:#000;font-weight: bold;'
console.log(`%c *****  School Store Log Color  ***** `, `${styleAlertColor}`)

export const useSchoolStore = defineStore('schoolStore', {
  state: () => ({
    school: {
      data: {},
      isLoaded: false
    }
  }),
  getters: {
    schoolName: state => state.school.data.schoolName,
    isPretest: state => state.school.data.pretestStatus,
    isPosttest: state => state.school.data.posttestStatus
  },
  actions: {
    async getSchool () {
      if (this.school.isLoaded) return
      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/school-getSchool?schoolId=${studentStore.schoolId}&courseId=${studentStore.courseId}`

        const response = await axios.get(APIURL)

        this.$patch({
          school: {
            data: response.data,
            isLoaded: true
          }
        })

        this.log(`Success Get School`)
      } catch (e) {
        this.log(`Error Get School`)

        return e
      }
    },
    log (text) {
      const systemStore = useSystemStore()

      if (systemStore.isShowLog)
        console.log(`%c ${text} `, `${styleAlertColor}`)
    }
  }
})
