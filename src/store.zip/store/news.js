import axios from 'axios'
import { defineStore } from 'pinia'
import { useStudentStore } from './student'
import { useSystemStore } from './system'

// Initialize Data
const styleAlertColor = 'color:#f6ff00;background-color:#000;font-weight: bold;'
console.log(`%c *****  News Store Log Color  ***** `, `${styleAlertColor}`)

export const useNewsStore = defineStore('newsStore', {
  state: () => ({
    news: {
      data: [],
      isLoaded: false
    },
    newsLog: {
      data: [],
      isLoaded: false,
      isUpdate: false
    }
  }),
  getters: {
    isReadAll: state => {
      let checkReadAll = state.news.data.every(
        x => x.id == state.newsLog.data.find(y => y === x.id)
      )

      return checkReadAll
    }
  },
  actions: {
    async getNews () {
      if (this.news.isLoaded) return

      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/news-getNewsByStudentType?studentType=${studentStore.studentType}`

        const response = await axios.get(APIURL)

        this.$patch({
          news: {
            data: response.data,
            isLoaded: true
          }
        })
        this.log(`Success Get News`)
      } catch (e) {
        this.log(`Error Get News`)

        return e
      }
    },

    async getNewLog () {
      if (this.newsLog.isLoaded) return

      try {
        const studentStore = useStudentStore()

        const APIURL = `${process.env.NEWAPI}/newsLog-getNewsLogByStudentId?studentId=${studentStore.studentId}`

        const response = await axios.post(APIURL)

        this.$patch({
          newsLog: {
            data: response.data,
            isLoaded: true
          }
        })
        this.log(`Success Get News Log`)
      } catch (e) {
        this.log(`Error Get News Log`)

        return e
      }
    },

    funcReadNews (val) {
      let findNewsLog = this.newsLog.data.find(x => x === val.id)

      if (findNewsLog) return

      let temp = this.newsLog.data

      temp.push(val.id)

      this.$patch({
        newsLog: {
          isUpdate: true,
          data: temp
        }
      })
    },
    log (text) {
      const systemStore = useSystemStore()

      if (systemStore.isShowLog)
        console.log(`%c ${text} `, `${styleAlertColor}`)
    }
  }
})
