import axios from 'axios'
import { defineStore } from 'pinia'
import { useStudentStore } from './student'

const styleAlertColor = 'color:#fff;background-color:#000000;font-weight: bold;'
console.log(`%c *****  System Store Log Color  ***** `, `${styleAlertColor}`)

let backgroundAudioList = [
  new Audio('/sound/background/Vocabulary.mp3'),
  new Audio('/sound/background/Grammar.mp3'),
  new Audio('/sound/background/Reading.mp3'),
  new Audio('/sound/background/Writing.mp3'),
  new Audio('/sound/background/Phonics.mp3'),
  new Audio('/sound/background/Listening.mp3')
]

// Background Music
let backgroundLogin = new Audio('/sound/background/login.mp3')
let backgroundLobby = new Audio('/sound/background/lobby.mp3')
let backgroundVocabulary = new Audio('/sound/background/Vocabulary.mp3')
let backgroundGrammar = new Audio('/sound/background/Grammar.mp3')
let backgroundReading = new Audio('/sound/background/Reading.mp3')
let backgroundWriting = new Audio('/sound/background/Writing.mp3')
let backgroundPhonics = new Audio('/sound/background/Phonics.mp3')
let backgroundListening = new Audio('/sound/background/Listening.mp3')

// Sound Other
const soundCorrect = new Audio('/sound/effects/correct.mp3')
const soundInCorrect = new Audio(`/sound/effects/incorrect.mp3`)
const soundPass = new Audio('/sound/effects/pass.mp3')
const soundFail = new Audio('/sound/effects/fail.mp3')

let tempBackground
let tempEffect
let tempAudio

let setVolumeSoundBackground = 0.2

export const useSystemStore = defineStore('systemStore', {
  state: () => ({
    isDontShowNews: false,
    isShowLog: true,
    systemData: {
      isEnableSoundEffect: false,
      isEnableSoundBackground: false,
      isPlayVideo: false,
      routerName: '',
      platform: {
        desktop: false,
        mobile: false
      },
      status: 'online'
    }
  }),
  getters: {
    isEnableSoundEffect: state => {
      if (state.systemData.isPlayVideo) return false

      return state.systemData.isEnableSoundEffect
    },
    isEnableSoundBackground: state => {
      if (state.systemData.isPlayVideo) return false

      return state.systemData.isEnableSoundBackground
    },
    routerName: state => state.systemData.routerName,
    platform: state => state.systemData.platform,
    status: state => state.systemData.status
  },

  actions: {
    // Login
    async login (username, password) {
      const studentStore = useStudentStore()

      try {
        const APIURL = `${process.env.NEWAPI}/auth-checkLogin`

        const POSTDATA = {
          username: username,
          password: password
        }

        const response = await axios.post(APIURL, POSTDATA)

        studentStore.$patch({
          student: {
            data: response.data,
            uid: response.data.uid,
            isLoaded: true
          }
        })

        this.log('Success Login')
      } catch (e) {
        this.log('Error Login')

        return e
      }
    },
    async loginAuth () {
      const studentStore = useStudentStore()

      try {
        const APIURL = `${process.env.NEWAPI}/auth-createCustomToken?uid=`

        const response = await axios.get(APIURL + studentStore.studentId)

        this.log('Success Login Auth')

        await studentStore.getCharacterInfo()

        return response.data
      } catch (e) {
        this.log('Error Login Auth')

        return e
      }
    },
    async saveLoginLog () {
      const studentStore = useStudentStore()

      try {
        const APIURL = `${process.env.NEWAPI}/auth-saveLoginLog`

        const POSTDATA = {
          studentId: studentStore.studentId
        }

        const response = await axios.post(APIURL, POSTDATA)

        this.log('Success Save Login Log')
      } catch (e) {
        this.log('Error Save Login Log')
      }
    },
    getSystem (routeName) {
      this.$patch({
        systemData: {
          isEnableSoundEffect: true,
          isEnableSoundBackground: true,
          routerName: routeName
        }
      })

      this.playSoundBackground()
    },

    funcEnableSoundEffect (payload) {
      this.$patch({
        systemData: {
          isEnableSoundEffect: payload
        }
      })
    },

    funcEnableSoundBackground (payload) {
      this.$patch({
        systemData: {
          isEnableSoundBackground: payload
        }
      })

      this.playSoundBackground()
    },

    playVideo (payload) {
      this.systemData.isPlayVideo = payload

      this.playSoundBackground()
    },

    playSound (audio) {
      if (tempAudio) {
        tempAudio.pause()
      }

      if (tempBackground) {
        tempBackground.volume = 0.01
      }

      tempAudio = audio

      tempAudio.currentTime = 0
      tempAudio.volume = 1

      tempAudio.play()

      tempAudio.onended = () => {
        if (tempBackground) {
          tempBackground.volume = setVolumeSoundBackground
        }
      }
    },

    playSlowSound (audio) {
      if (tempAudio) {
        tempAudio.pause()
      }

      if (tempBackground) {
        tempBackground.volume = 0.01
      }

      tempAudio = audio

      tempAudio.currentTime = 0
      tempAudio.volume = 1

      tempAudio.playbackRate = 0.7

      tempAudio.play().then(() => {
        if (tempBackground) {
          tempBackground.volume = setVolumeSoundBackground
        }
      })
    },

    playSoundBackground () {
      if (tempBackground) {
        tempBackground.pause()
      }

      if (!this.isEnableSoundBackground) return

      if (this.routerName == 'Login') {
        tempBackground = backgroundLogin

        setVolumeSoundBackground = 0.2

        tempBackground.volume = setVolumeSoundBackground
      } else if (
        this.routerName == 'Lobby' ||
        this.routerName == 'practiceListSkill' ||
        this.routerName == 'practiceListUnit' ||
        this.routerName == 'PracticeListMain'
      ) {
        tempBackground = backgroundLobby

        setVolumeSoundBackground = 0.5

        tempBackground.volume = setVolumeSoundBackground
      } else if (this.routerName == 'Shop' || this.routerName == 'Equipment') {
        tempBackground = backgroundLobby

        setVolumeSoundBackground = 0.5

        tempBackground.volume = setVolumeSoundBackground
      } else if (this.routerName == 'Vocabulary') {
        tempBackground = backgroundVocabulary
        setVolumeSoundBackground = 0.3

        tempBackground.volume = setVolumeSoundBackground
      } else if (this.routerName == 'Grammar') {
        tempBackground = backgroundGrammar
        setVolumeSoundBackground = 0.3

        tempBackground.volume = setVolumeSoundBackground
      } else if (this.routerName == 'Reading') {
        tempBackground = backgroundReading
        setVolumeSoundBackground = 0.3

        tempBackground.volume = setVolumeSoundBackground
      } else if (this.routerName == 'Writing') {
        tempBackground = backgroundWriting
        setVolumeSoundBackground = 0.3

        tempBackground.volume = setVolumeSoundBackground
      } else if (this.routerName == 'Phonics') {
        tempBackground = backgroundPhonics
        setVolumeSoundBackground = 0.3

        tempBackground.volume = setVolumeSoundBackground
      } else if (this.routerName == 'Listening') {
        tempBackground = backgroundListening
        setVolumeSoundBackground = 0.3

        tempBackground.volume = setVolumeSoundBackground
      }

      tempBackground.play()

      tempBackground.onended = () => {
        tempBackground.play()
      }
    },

    playEffectCorrect () {
      if (tempEffect) {
        tempEffect.pause()
      }

      if (!this.isEnableSoundEffect) return

      if (tempBackground) {
        if (this.isEnableSoundBackground) tempBackground.volume = 0.01
      }

      tempEffect = soundCorrect

      tempEffect.currentTime = 0
      tempEffect.volume = 0.5

      tempEffect.play()

      tempEffect.onended = () => {
        if (tempBackground) {
          if (this.isEnableSoundBackground)
            tempBackground.volume = setVolumeSoundBackground
        }
      }
    },

    playEffectIncorrect () {
      if (tempEffect) {
        tempEffect.pause()
      }

      if (!this.isEnableSoundEffect) return

      if (tempBackground) {
        if (this.isEnableSoundBackground) tempBackground.volume = 0.01
      }

      tempEffect = soundInCorrect

      tempEffect.currentTime = 0
      tempEffect.volume = 0.5

      tempEffect.play()

      tempEffect.onended = () => {
        if (tempBackground) {
          if (this.isEnableSoundBackground)
            tempBackground.volume = setVolumeSoundBackground
        }
      }
    },

    playEffectPass () {
      if (tempEffect) {
        tempEffect.pause()
      }

      if (!this.isEnableSoundEffect) return

      if (tempBackground) {
        if (this.isEnableSoundBackground) tempBackground.volume = 0.01
      }

      tempEffect = soundPass

      tempEffect.currentTime = 0
      tempEffect.volume = 0.5

      tempEffect.play()

      tempEffect.onended = () => {
        if (tempBackground) {
          if (this.isEnableSoundBackground)
            tempBackground.volume = setVolumeSoundBackground
        }

        tempEffect.pause()
      }
    },

    playEffectFail () {
      if (tempEffect) {
        tempEffect.pause()
      }

      if (!this.isEnableSoundEffect) return

      if (tempBackground) {
        if (this.isEnableSoundBackground) tempBackground.volume = 0.01
      }

      tempEffect = soundFail

      tempEffect.currentTime = 0
      tempEffect.volume = 0.5

      tempEffect.play()

      tempEffect.onended = () => {
        if (tempBackground) {
          if (this.isEnableSoundBackground)
            tempBackground.volume = setVolumeSoundBackground
        }

        tempEffect.pause()
      }
    },

    // Other
    callbackPathRouterPractice (data) {
      let setNewSkill = data.skill
      let setNewType = data.page || data.practiceType
      let setPracticeListId = data.id || data.practiceListId

      let path = '/lobby'
      if (data.skill == 'Listening & Speaking') setNewSkill = 'Listening'

      if (data.skill == 'Vocabulary') {
        if (setNewType == 'flashcard') {
          path = '/flashcard/'
        } else if (setNewType == 'matching') {
          path = '/matching/'
        } else if (setNewType == 'spellingbee') {
          path = '/spellingbee/'
        } else if (setNewType == 'multiplevocab') {
          path = '/multiplevocab/'
        }

        path = `${path}${setPracticeListId}`

        return path
      } else if (data.skill == 'Grammar') {
        if (setNewType == 'grammarmultiple') {
          path = '/grammarmultiple/'
        } else if (setNewType == 'grammaraction') {
          path = '/grammarAction/'
        } else {
          path = '/vdoLesson/'
        }

        path = `${path}${setPracticeListId}`

        return path
      }
      // Reading
      else if (data.skill == 'Reading') {
        if (setNewType == 'readingmultiple') {
          path = '/readingmultiple/'
        }
        path = `${path}${setPracticeListId}`

        return path
      }
      // Writing
      else if (data.skill == 'Writing') {
        if (setNewType == 'translation') {
          path = '/translation/'
        }

        path = `${path}${setPracticeListId}`

        return path

        // return '/lobby'
      }
      // Phonics
      else if (data.skill == 'Phonics') {
        if (setNewType == 'vdoLesson') {
          path = '/vdoLesson/'
        } else {
          path = '/phonicsMultiple/'
        }

        path = `${path}${setPracticeListId}`

        return path

        return '/lobby'
      } // Listening & Speaking
      else if (data.skill == 'Listening & Speaking') {
        if (setNewType == 'vdoLesson') {
          path = '/vdoLesson/'
        } else if (setNewType == 'conversationlesson') {
          path = '/conversationLesson/'
        } else if (setNewType == 'roleplay') {
          path = '/roleplay/'
        } else if (setNewType == 'languagetipmultiple') {
          path = '/languagetipmultiple/'
        } else if (setNewType == 'conversationmultiple') {
          path = '/conversationMultiple/'
        }

        path = `${path}${setPracticeListId}`

        return path

        // return '/lobby'
      } else {
        if (setNewType.includes('multiplechoices')) {
          if (data.skill == 'Vocabulary') {
            path = '/multiplevocab/'
          } else if (data.skill == 'Grammar') {
            path = '/grammarmultiple/'
          } else if (data.skill == 'Phonics') {
            path = '/phonicsMultiple/'
          } else if (data.skill == 'Reading') {
            path = '/readingmultiple/'
          } else if (data.skill == 'Listening & Speaking') {
            if (setNewType == 'multiplechoices(answersound)') {
              path = '/conversationmultiple/'
            } else {
              path = '/languagetipmultiple/'
            }
          }
        } else if (setNewType == 'spellingbee') {
          path = '/spellingbee/'
        } else if (
          setNewType == 'grammarlesson' ||
          setNewType == 'phonicslesson' ||
          setNewType == 'languagetips'
        ) {
          path = '/vdoLesson/'
        } else if (setNewType == 'grammaraction') {
          path = '/grammarAction/'
        } else if (setNewType == 'translation') {
          path = '/translation/'
        } else if (setNewType == 'clozetest') {
          path = '/clozeTest/'
        } else if (setNewType == 'conversationlesson') {
          path = '/conversationLesson/'
        } else if (setNewType == 'roleplay') {
          path = '/roleplay/'
        }

        path = `${path}${setPracticeListId}`

        return path
      }
    },
    // Setter System Data
    setRouter (routerName) {
      this.$patch({
        systemData: {
          routerName: routerName
        }
      })

      this.log(`Change Router : ${routerName}`)

      this.playSoundBackground()
    },
    setPlatform (platform) {
      let isDesktop = true
      let isMobile = true

      if (platform == 'desktop') isDesktop = true
      else isDesktop = false

      if (platform == 'mobile') isMobile = true
      else isMobile = false

      this.$patch({
        systemData: {
          platform: {
            desktop: isDesktop,
            mobile: isMobile
          }
        }
      })
    },
    setStatus (status) {
      this.$patch(state => (state.systemData.status = status))
    },
    log (text) {
      if (this.isShowLog) {
        console.log(`%c ${text} `, `${styleAlertColor}`)
        console.log(' ')
      }
    }
  }
})

// if (
//   setNewType == 'flashcard' ||
//   setNewType == 'grammarlesson' ||
//   setNewType == 'phonicslesson' ||
//   setNewType == 'languagetips' ||
//   setNewType == 'conversationlesson'
// ) {
//   if (setNewType == 'languagetips') path = `/learning/languagetips`
//   else if (setNewType == 'conversationlesson')
//     path = `/learning/conversation`
//   else path = `/learning/${setNewSkill.toLowerCase()}`
// } else if (
//   setNewType == 'multiplechoices' ||
//   setNewType == 'multiplevocab'
// ) {
//   let typeOfPractice = setNewType
//   if (setNewType == 'multiplechoices' || setNewType == 'multiplevocab')
//     typeOfPractice = 'multiple'
//   path = `/practice/${setNewSkill.toLowerCase()}/${typeOfPractice}`
// }
